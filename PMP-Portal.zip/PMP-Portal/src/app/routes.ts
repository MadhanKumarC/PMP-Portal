import { Routes } from '@angular/router';
import { AddUserComponent} from './User/add-user.component';
import { AddProjectComponent } from './project/add-project.component';

export const appRoutes : Routes = [
    {path:'users', component:AddUserComponent},
    {path:'projects', component:AddProjectComponent},
    {path:'', redirectTo: '/users', pathMatch:'full'}
]